@file:OptIn(InternalResourceApi::class)

package reelsdemo.composemultiplatformmediaplayer.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String =
    "composeResources/reelsdemo.composemultiplatformmediaplayer.generated.resources/"

@delegate:ResourceContentHash(1_372_890_498)
internal val Res.drawable.resize_fill: DrawableResource by lazy {
      DrawableResource("drawable:resize_fill", setOf(
        ResourceItem(setOf(), "${MD}drawable/resize_fill.png", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-46_559_623)
internal val Res.drawable.resize_fit: DrawableResource by lazy {
      DrawableResource("drawable:resize_fit", setOf(
        ResourceItem(setOf(), "${MD}drawable/resize_fit.png", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("resize_fill", Res.drawable.resize_fill)
  map.put("resize_fit", Res.drawable.resize_fit)
}
